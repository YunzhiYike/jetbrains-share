1. 下载需要用到的Jetbrains产品 && 安装
2. windows环境下执行scripts/install.vbs、Mac OS 环境下执行 scripts/install.sh
3. 打开安装好的软件根目录将vmoptions/对应的文件复制替换


【集合分享地址：jetbrains.yunzhiyike.com】